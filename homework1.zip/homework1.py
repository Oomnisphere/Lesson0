example='oOmnisphere'
print(example[0])
print(example[-1])
print(example[4:])
print(example[::-1])
print(example[::2])