name='Sasha'
print('Name: '+name)
age=40
print('Age:',age)
age=42
print('New age:',age)
is_student=True
print('Is Student:',is_student)